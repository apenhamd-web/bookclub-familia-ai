# Guia de Discussão — Torto Arado (Itamar Vieira Junior)
## Perguntas-chave
1. Terra e pertencimento: posse vs pertencimento.
2. Trabalho e captura do futuro: mecanismos de permanência.
3. Voz e silêncio: o que muda com as vozes narrativas?
4. Cura, religião e poder: proteção vs controle.
5. Violência estrutural: o que aparece sem “cena” explícita?
## Ritual
- 1 citação + 1 pergunta por pessoa.
