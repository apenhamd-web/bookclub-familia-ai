# Guia de Discussão — Relato de um Certo Oriente (Milton Hatoum)
## Perguntas-chave
1. Memória como montagem: lembrança vs invenção necessária.
2. Casa & exílio: o que é “voltar” quando tudo mudou?
3. Família como arquivo: quem guarda/apaga/reescreve?
4. Manaus como personagem: que Manaus aparece?
5. Fragmento/oralidade: por que a forma é o conteúdo?
## Ritual
- 1 citação + 1 pergunta por pessoa.
