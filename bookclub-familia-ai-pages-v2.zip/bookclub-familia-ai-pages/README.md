# Bookclub – Família AI (FMM Informática) — GitHub Pages

## Publicar
1. Crie um repositório no GitHub (ex: `bookclub-familia-ai`).
2. Faça upload do conteúdo desta pasta na raiz do repo.
3. GitHub: **Settings → Pages**
   - Source: **Deploy from a branch**
   - Branch: **main** / **/(root)**
4. Acesse: `https://SEUUSUARIO.github.io/bookclub-familia-ai/`

## Calendário
Importe `bookclub_familia_ai_2026.ics` no Google Calendar.
